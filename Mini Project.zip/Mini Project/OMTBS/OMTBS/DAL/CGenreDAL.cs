﻿using System;
using System.Windows;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using EntitiesLayer;
using ExceptionLayer;

namespace DAL {
    public class CGenreDAL {
        static string connectionString;
        static string providerName;
        static DbProviderFactory factory = null;
        public CGenreDAL() {
            connectionString = ConnectionStrings.CONNECTION_STRING;
            providerName = ConnectionStrings.PROVIDER_NAME;
            factory = DbProviderFactories.GetFactory(providerName);
        }
        public bool MNewGenreEntryDAL(GenreEntities genreEntity) {
            bool genreAdded = false;
            DbConnection conn = null;
            DbCommand cmd = null;
            DbParameter param = null;
            int affectedRows = 0;

            try {
                conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "NewGenreEntry";

                param = cmd.CreateParameter();
                //param.ParameterName = "@genreID";
                //param.DbType = DbType.Int32;
                //param.Value = genreEntity.GENRE_GENREID;
                //cmd.Parameters.Add(param);
                //param = null;

                //param = cmd.CreateParameter();
                param.ParameterName = "@genreName";
                param.DbType = DbType.String;
                param.Value = genreEntity.GENRE_GENRENAME;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@desc";
                param.DbType = DbType.String;
                param.Value = genreEntity.GENRE_GENREDESCRIPTION;
                cmd.Parameters.Add(param);
                param = null;

                cmd.Connection.Open();
                affectedRows = cmd.ExecuteNonQuery();
                if(affectedRows > 0) {
                    genreAdded = true;
                }
            } catch (Exception ex) {
                throw new GenreException(ex.Message);
            }

            return genreAdded;
        }

        public bool MUpdateGenreDAL(GenreEntities genreEntity) {
            bool genreUpdated = false;
            DbConnection conn = null;
            DbCommand cmd = null;
            DbParameter param = null;
            int affectedRows = 0;
            try
            {
                conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UpdateGenre";

                param = cmd.CreateParameter();
                param.ParameterName = "@genreID";
                param.DbType = DbType.Int32;
                param.Value = genreEntity.GENRE_GENREID;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@genreName";
                param.DbType = DbType.String;
                param.Value = genreEntity.GENRE_GENRENAME;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@desc";
                param.DbType = DbType.String;
                param.Value = genreEntity.GENRE_GENREDESCRIPTION;
                cmd.Parameters.Add(param);
                param = null;

                cmd.Connection.Open();
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                {
                    genreUpdated = true;
                }
            }
            catch(DbException ex)
            {
                throw new GenreException(ex.Message);
            }
            catch (Exception ex) {
                throw new GenreException(ex.Message);
            }
                return genreUpdated;
        }
        public bool MDeleteGenreDAL(string genreName) {
            bool genreDeleted = false;
            DbConnection conn = null;
            DbCommand cmd = null;
            DbParameter param = null;
            int affectedRows = 0;

            try {
                conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DeleteGenreName";

                param = cmd.CreateParameter();
                param.ParameterName = "@genreName";
                param.DbType = DbType.String;
                param.Value = genreName;
                cmd.Parameters.Add(param);
                param = null;

                cmd.Connection.Open();
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0) {
                    genreDeleted = true;
                }
            } catch (Exception ex) {
                throw new GenreException(ex.Message);
            }

            return genreDeleted;
        }
    }
}
