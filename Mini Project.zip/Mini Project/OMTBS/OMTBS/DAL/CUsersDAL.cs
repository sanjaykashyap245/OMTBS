﻿using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExceptionLayer;
using System.Data;

namespace DAL
{
    public class CUsersDAL
    {
        public bool MUserLoginAuthenticationDAL(UsersEntities userObj)
        {
            bool isAuthenticated = false;
            DbCommand command = null;
            DbParameter param = null;

            try
            {
                command = DataConnection.CreateCommand();
                command.CommandText = "UserLogin";

                param = command.CreateParameter();
                param.ParameterName = "@username";
                param.DbType = DbType.String;
                param.Value = userObj.USERS_USERNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@password";
                param.DbType = DbType.String;
                param.Value = userObj.USERS_PASSWORD;
                command.Parameters.Add(param);

                DataTable data= DataConnection.ExecuteSelectCommand(command);

                if (data.Rows.Count > 0)
                    isAuthenticated = true;
            }
            catch (Exception ex)
            {
                throw new UserException(ex.Message);
            }
            return isAuthenticated;
        }
    }
}
