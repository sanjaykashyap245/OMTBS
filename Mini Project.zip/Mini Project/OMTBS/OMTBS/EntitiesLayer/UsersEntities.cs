﻿using System;

namespace EntitiesLayer {
    public class UsersEntities {
        #region Properties
        public int USERS_ID { get; set; }
        public string USERS_USERNAME { get; set; }
        public string USERS_PASSWORD { get; set; }
        #endregion
    }
}
