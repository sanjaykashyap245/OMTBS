﻿using System;

namespace EntitiesLayer {
    public class MoviesEntities {
        public int MOVIES_MOVIEID { get; set; }
        public string MOVIES_MOVIENAME { get; set; }
        public DateTime MOVIES_RELEASEDATE { get; set; }
        public int MOVIES_GENREID { get; set; }
        public string MOVIES_GENRENAME { get; set; }
        public string MOVIES_DESCRIPTION { get; set; }
    }
}
