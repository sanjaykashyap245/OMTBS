﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    public class UserException : ApplicationException
    {
        public UserException() : base()
        {

        }
        public UserException(string message) : base(message)
        {

        }
        public UserException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
