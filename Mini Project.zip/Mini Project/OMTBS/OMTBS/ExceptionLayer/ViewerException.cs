﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    public class ViewerException : ApplicationException
    {
        public ViewerException() : base()
        {

        }
        public ViewerException(string message, Exception innerException) : base(message,innerException)
        {
                
        }
        public ViewerException(string message)
        {

        }
    }
}
