﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    public class ShowsException : ApplicationException
    {
        public ShowsException() : base()
        {

        }
        public ShowsException(string message) : base(message)
        {

        }
        public ShowsException(string message, Exception innerException) : base(message,innerException) 
        {
                
        }
    }
}
