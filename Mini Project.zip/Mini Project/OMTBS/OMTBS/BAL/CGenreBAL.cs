﻿using DAL;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class CGenreBAL {
        static bool AddGenreValidation(GenreEntities genreEntity) {
            StringBuilder errorString = new StringBuilder();
            bool isValid = true;

                if (genreEntity.GENRE_GENRENAME.Equals(string.Empty)) {
                isValid = false;
                errorString.AppendLine("Genre Name cannot be empty");
            }
            if (genreEntity.GENRE_GENREDESCRIPTION.Equals(string.Empty)) {
                isValid = false;
                errorString.AppendLine("Description cannot be empty");
            }
            // Display errorString code to be written
            if (errorString.Length != 0)
                throw new Exception(errorString.ToString());
            return isValid;
        }
        static bool UpdateGenreValidation(GenreEntities genreEntity)
        {
            StringBuilder errorString = new StringBuilder();
            bool isValid = true;

            if(genreEntity.GENRE_GENREID == 0)
            {
                isValid = false;
                errorString.AppendLine("Provide the GenreID for for the GenreName to be updated");
            }
            if (genreEntity.GENRE_GENRENAME.Equals(string.Empty))
            {
                isValid = false;
                errorString.AppendLine("Genre Name cannot be empty");
            }
            if (genreEntity.GENRE_GENREDESCRIPTION.Equals(string.Empty))
            {
                isValid = false;
                errorString.AppendLine("Description cannot be empty");
            }
            // Display errorString code to be written
            if (errorString.Length != 0)
                throw new Exception(errorString.ToString());
            return isValid;
        }
        public static bool MNewGenreEntryBAL(GenreEntities genreEntity) {
            if (AddGenreValidation(genreEntity)) {
                return new CGenreDAL().MNewGenreEntryDAL(genreEntity);
            }
            return false;
        }
        public static bool MUpdateGenreBAL(GenreEntities genreEntity) {
            if (genreEntity.GENRE_GENREID != 0 && UpdateGenreValidation(genreEntity)) {
                return new CGenreDAL().MUpdateGenreDAL(genreEntity);
            }
            return false;
        }
        public static bool MDeleteGenreDAL(string genreName) {
            if (!genreName.Equals(string.Empty)) {
                return new CGenreDAL().MDeleteGenreDAL(genreName);
            }
            return false;
        }
    }
}
