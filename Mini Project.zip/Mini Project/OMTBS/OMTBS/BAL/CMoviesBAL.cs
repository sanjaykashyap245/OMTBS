﻿using DAL;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL {
    class CMoviesBAL
    {
        static bool AddMovieValidations(MoviesEntities movieObj)
        {
            bool isValid = true;
            StringBuilder errorMessage = new StringBuilder();
            if (movieObj.MOVIES_MOVIENAME.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Movie Name cannot be empty");
            }
            if (movieObj.MOVIES_RELEASEDATE.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Release Date cannot be empty");
            }
            if (movieObj.MOVIES_GENREID == 0)
            {
                isValid = false;
                errorMessage.AppendLine("Genre Id cannot be empty");
            }
            if (movieObj.MOVIES_DESCRIPTION.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Provide Description for the movie");
            }
            if (errorMessage.Length != 0)
            {
                throw new Exception(errorMessage.ToString());
            }
            return isValid;
        }
        static bool UpdateMovieDetailsValidations(MoviesEntities movieObj)
        {
            bool isValid = true;
            StringBuilder errorMessage = new StringBuilder();
            if (movieObj.MOVIES_MOVIEID == 0)
            {
                isValid = false;
                errorMessage.AppendLine("Provide MovieID for which the Information needs to be updated");
            }
            if (movieObj.MOVIES_MOVIENAME.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Movie Name cannot be empty");
            }
            if (movieObj.MOVIES_RELEASEDATE.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Release Date cannot be empty");
            }
            if (movieObj.MOVIES_GENREID == 0)
            {
                isValid = false;
                errorMessage.AppendLine("Genre Id cannot be empty");
            }
            if (movieObj.MOVIES_DESCRIPTION.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Provide Description for the movie");
            }
            if (errorMessage.Length != 0)
            {
                throw new Exception(errorMessage.ToString());
            }
            return isValid;
        }
        public static bool MAddNewMovieEntryBAL(MoviesEntities movieObj)
        {
            if (AddMovieValidations(movieObj))
            {
                return new CMoviesDAL().MAddNewMovieDAL(movieObj);
            }
            return false;
        }
        public static bool MUpdateMovieEntryBAL(MoviesEntities movieObj)
        {
            if (UpdateMovieDetailsValidations(movieObj))
            {
                return new CMoviesDAL().MUpdateMovieDAL(movieObj);
            }
            return false;
        }
        public static List<MoviesEntities> MGetRecentMoviesBAL()
        {
            return new CMoviesDAL().MGetRecentMoviesDAL();
        }
        public static List<MoviesEntities> MGetAllMoviesDBAL()
        {
            return new CMoviesDAL().MGetAllMoviesDAL();
        }
        public MoviesEntities MGetMovieDetailsByIDDAL(int movieID)
        {
            if (movieID == 0)
            {
                throw new Exception("Enter a MovieID");
            }
            else
                return new CMoviesDAL().MGetMovieDetailsByIDDAL(movieID);
        }
    }
}
