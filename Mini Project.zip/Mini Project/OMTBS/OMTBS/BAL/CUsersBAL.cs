﻿using DAL;
using EntitiesLayer;
using ExceptionLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    public class CUsersBAL
    {
        static bool CredentialsValidation(UsersEntities userObj)
        {
            StringBuilder errorMessage = new StringBuilder();
            bool isValid = true;
            if(userObj.USERS_USERNAME.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Enter a username");
            }
            if(userObj.USERS_PASSWORD.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Provide a password");
            }
            if(errorMessage.Length !=0)
            {
                throw new Exception(errorMessage.ToString());
            }
            return isValid;
        }
        public static bool MUserLoginAuthenticationBAL(UsersEntities userObj)
        {
            if(CredentialsValidation(userObj))
                return new CUsersDAL().MUserLoginAuthenticationDAL(userObj);
            return false;
        }
    }
}
